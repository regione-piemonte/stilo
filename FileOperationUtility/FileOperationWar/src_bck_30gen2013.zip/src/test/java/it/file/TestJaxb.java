package it.file;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

 

import it.eng.cryptoutil.verify.beans.FileOperationResults;
import it.eng.cryptoutil.verify.beans.ResponseUnpackType;
import it.eng.cryptoutil.verify.beans.VerificationStatusType;

public class TestJaxb {
	
	public static void main(String[] args) throws Exception {
		FileOperationResults result = new FileOperationResults();
		ResponseUnpackType r1=new ResponseUnpackType();
		r1.setVerificationStatus(VerificationStatusType.OK);
		result.getFileOperationResult().add(r1);
		JAXBContext jc = JAXBContext.newInstance("it.eng.cryptoutil.verify.beans");
		//Creare il marshaller
		Marshaller m = jc.createMarshaller();
		//Eseguire il marshalling dell'oggetto nel file.
		m.marshal(result, System.out);
		Unmarshaller um = jc.createUnmarshaller();
		// 
		   
		FileOperationResults unmarshalled = new FileOperationResults();
		unmarshalled=(FileOperationResults)um.unmarshal(new java.io.FileInputStream( "C:/spazilavoro/aurigaserv/CryptoService/src/test/java/it/file/test.xml" ));
		Class clazz=unmarshalled.getFileOperationResult().get(0).getClass();
		System.out.println("\nread:"+clazz);
	}
}
