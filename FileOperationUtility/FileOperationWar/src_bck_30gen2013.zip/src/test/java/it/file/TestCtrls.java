package it.file;

import it.eng.cryptoutil.file.FileOperationController;
import it.eng.cryptoutil.file.FormatRecognitionCtrl;
import it.eng.cryptoutil.file.IFileController;
import it.eng.cryptoutil.file.InputFileBean;
import it.eng.cryptoutil.file.UnpackCtrl;
import it.eng.cryptoutil.file.beans.OutputOperations;

import java.io.File;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCtrls {

	public static void main(String[] args) throws Exception {
		//ApplicationContext context = new ClassPathXmlApplicationContext("ControllerConfig.xml"); 
		ApplicationContext context = new ClassPathXmlApplicationContext("FileOperationConfig.xml");
		UnpackCtrl ctrl=context.getBean(UnpackCtrl.class);
		IFileController fr=context.getBean(FormatRecognitionCtrl.class);
		FileOperationController foc= new FileOperationController();
		foc.addCtrl(ctrl);
		foc.addCtrl(fr);
		InputFileBean ifb= new InputFileBean();
		ifb.setInputFile(new File("c:/testoodt.odt.p7m"));
		OutputOperations ops=foc.executeControll(ifb);
		System.out.println("ops:"+ops);
	}
}
