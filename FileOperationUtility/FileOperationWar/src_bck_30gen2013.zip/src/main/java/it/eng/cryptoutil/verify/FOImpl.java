package it.eng.cryptoutil.verify;

import it.eng.core.annotation.Operation;
import it.eng.core.annotation.Service;
import it.eng.cryptoutil.file.FileOperationController;
import it.eng.cryptoutil.file.InputFileBean;
import it.eng.cryptoutil.file.beans.OutputOperations;
import it.eng.cryptoutil.verify.beans.FileOperation;
import it.eng.cryptoutil.verify.beans.FileOperationResults;
import it.eng.cryptoutil.verify.util.InputFileUtil;
import it.eng.utility.cryptosigner.controller.exception.ExceptionController;

import java.io.File;
import java.io.FileInputStream;

import javax.jws.WebService;

@WebService(endpointInterface = "it.eng.cryptoutil.verify.FileOperationWS")
@Service(name="FOImpl")
public class FOImpl implements FileOperationWS{

	@Override
	@Operation(name="eseguiOperazioni")
	public FileOperationResults check(FileOperation input) {
//		DataHandler dh=input.getFileOperationInput().getInputType().getFileStream();
//		OutputStream os;
//		try {
//			os = new FileOutputStream(new File("c:/myFile"));
//			dh.writeTo(os);
//			//IOUtils.copyLarge(dh.getInputStream(), os);
//			//IOUtils.closeQuietly(dh.getInputStream());
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}finally{
//			
//		}
		File file;
		try{
		  file=InputFileUtil.getTempFile(input.getFileOperationInput().getInputType());
		}catch(Exception ex){
			//
			ex.printStackTrace();
			return null;
		}
		FileOperationController foc= new FileOperationController();
		InputFileBean ifb = new InputFileBean();
		ifb.setInputFile(file);
		//costruisce i ctrl in base all'input passato 
		foc.buildCtrl(input);
		OutputOperations result=null;
		try {
			result=foc.executeControll(ifb);
		} catch (ExceptionController e) {
			// 
			e.printStackTrace();
		}
		System.out.println("called..");
		//build response
		FileOperationResults ret= new FileOperationResults();
		ret.getFileOperationResult().addAll(result.getResponses());
		return ret;
	}
	
	 
}
