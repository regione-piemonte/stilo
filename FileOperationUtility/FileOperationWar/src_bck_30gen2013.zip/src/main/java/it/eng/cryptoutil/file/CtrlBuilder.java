package it.eng.cryptoutil.file;

import it.eng.cryptoutil.verify.beans.AbstractInputOperationType;

public interface CtrlBuilder {

	public IFileController build(AbstractInputOperationType input);
}
