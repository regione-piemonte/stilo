package it.eng.cryptoutil.file;

import java.io.File;


/**
 * bean di input per analizeffetuare controlli su un file
 * @author Russo
 *
 */
public class InputFileBean {
	private File inputFile;
	private String fileName;
	
	public File getInputFile() {
		return inputFile;
	}
	public void setInputFile(File inputFile) {
		this.inputFile = inputFile;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
}
