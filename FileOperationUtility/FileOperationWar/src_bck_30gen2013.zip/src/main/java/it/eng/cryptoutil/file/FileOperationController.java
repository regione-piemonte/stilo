package it.eng.cryptoutil.file;

import it.eng.cryptoutil.file.beans.OutputOperations;
import it.eng.cryptoutil.verify.beans.AbstractInputOperationType;
import it.eng.cryptoutil.verify.beans.FileOperation;
import it.eng.cryptoutil.verify.beans.FileOperation.Operations;
import it.eng.utility.cryptosigner.controller.exception.ExceptionController;
import it.eng.utility.cryptosigner.data.SignerUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * Implementa la gestione dei controller.
 * L'analisi viene innescata dalla chiamata al metodo {@link FileOperationController#executeControll(InputFileBean)} 
 * e iterata su tutti i controller definiti nell'attributo controllers
 * @author Stefano Zennaro
 *
 */
public class FileOperationController {
	
	private static Logger log = LogManager.getLogger(FileOperationController.class);
	
	//Directory temporanea di appoggio per la gestione dei file temporanei
	private File temporarydirectroy = new File(System.getProperty("java.io.tmpdir"));

	// Controller da invocare per l'analisi
	private List<IFileController> controllers;

	// Mappa dei flag indicanti i controlli da effettuare
	private Map<String,Boolean> checks;
	
 
	
	// Indica se uno dei controlli bloccanti non e andato a buon fine
	private boolean interrupted = false;
	
	// Ausiliario
	private SignerUtil signerUtil = SignerUtil.newInstance();
	
	
	public File getTemporarydirectroy() {
		return temporarydirectroy;
	}

	public void setTemporarydirectroy(File temporarydirectroy) {
		this.temporarydirectroy = temporarydirectroy;
	}
	
	/**
	 * Directory temporanea dedicata per la gestione dei file di appoggio
	 */
	private File dedicatedTemporyDirectory;
	
	public FileOperationController() {
		String dedicated = StringUtils.remove(UUID.randomUUID().toString(),"-");
		dedicatedTemporyDirectory = new File(temporarydirectroy,dedicated);
		dedicatedTemporyDirectory.mkdirs();
	}
	
	
	
	public File getDedicatedTemporyDirectory() {
		return dedicatedTemporyDirectory;
	}

	/**
	 * Recupera i controller configurati
	 * @return i controller configurati
	 */
	public List<IFileController> getControllers() {
		return controllers;
	}

	/**
	 * Definisce i controller su cui effettuare l'analisi
	 * @param controllers la lista dei controlli cui cui iterare l'analisi
	 */
	public void setControllers(List<IFileController> controllers) {
		this.controllers = controllers;
	}
	
	
	/**
	 * Effettua l'analisi richiamando l'esecuzione di ciascun 
	 * controller configurato. 
	 * @param input bean contenente le informazioni in input per eseguire i controlli
	 * @return bean
	 * @throws ExceptionController
	 */
	public OutputOperations executeControll(InputFileBean input)throws ExceptionController{
		OutputOperations output = new OutputOperations();
		List<IFileController> controllers = getControllers();
		//riordino i controllers definitivi da eseguire  in base alla priority
//		TreeSet<IFileController> sets=new TreeSet<IFileController>(new PriorityComparator());
//		sets.addAll(getControllers());
//		controllers.clear();
//		controllers.addAll(sets);
		Collections.sort(getControllers(),new PriorityComparator());
		System.out.println("controllers:"+controllers);
		this.execute(input, output);
		return output;
	}
	
	public void buildCtrl(FileOperation input){
		//read operation and build relative controller
		//crea la lista ordinata delle op richieste in base alla priorita'
		List<IFileController> ctrls=new ArrayList<IFileController>();
		Operations operations=input.getOperations();
		 List<AbstractInputOperationType> ops=operations.getOperation();
		 CtrlBuilder builder=FileCtrlFactory.getCtrlBuilder();
		 for (AbstractInputOperationType abstractInputOperationType : ops) {
			IFileController ctrl=builder.build(abstractInputOperationType);
			if(ctrl!=null){
				ctrls.add(ctrl);
			}
		}
		 Collections.sort(ctrls,new PriorityComparator());
		//aggiungi i ctrl alla lista di quelli da eseguire considerendo le dipendenze
		 for (IFileController ctrl : ctrls) {
			 addCtrl(ctrl);
		}
	}
	
	public void addCtrl(IFileController ctrl){
		//verifico se è già presente
		if(ctrl.getPredecessors()!=null && ctrl.getPredecessors().size()>0){
			for (IFileController iFileController : ctrl.getPredecessors()) {
				addCtrl(iFileController);
			}
		}
		if(!containsCtrl(ctrl.getClass())){
			controllers.add(ctrl);
		}
		 
	}
	private boolean containsCtrl(Class clazz){
		boolean ret=false;
		if(controllers==null){
			controllers=new ArrayList<IFileController>();
		}
		for (IFileController iFileController : getControllers()) {
			if(iFileController.getClass().equals(clazz)){
				ret=true;
				break;
			}
		}
		return ret;
	}
	/**
	 * Esegue la sequenza di controlli sul bean di input, 
	 *
	 */
	private void execute(InputFileBean input,OutputOperations output)throws ExceptionController{
		boolean result;
//		input.setChecks(checks);
		 
		for (IFileController controller:controllers) {
//			if (controller.canExecute(input)) {
				try {
					long start = System.currentTimeMillis();
					result = controller.execute(input,null, output);
					if (!result && controller.isCritical()) {
						//output.setProperty(OutputFileBean.MASTER_SIGNER_EXCEPTION_PROPERTY, controller.getClass().getName());
						interrupted = true;
						break;
					}
					long elapsedTimeMillis = System.currentTimeMillis()-start;
					log.debug("Controllo: " + controller.getClass().getSimpleName() + " eseguito con successo in " + elapsedTimeMillis + "ms");
				}catch(ExceptionController e) {
					if (controller.isCritical()) {
						interrupted = true;
						//output.setProperty(OutputFileBean.MASTER_SIGNER_EXCEPTION_PROPERTY, controller.getClass().getName());
						throw e;
					}
				}
				
//			}
		}
	}
	
 

	/**
	 * Recupera la mappa dei flag dei controlli
	 * @return la mappa dei flag
	 */
	public Map<String, Boolean> getChecks() {
		return checks;
	}

	/**
	 * Definisce i flag dei controlli da effettuare
	 * @param checks la mappa contenente i flag dei controlli e il loro valore (true/false)
	 */
	public void setChecks(Map<String, Boolean> checks) {
		this.checks = checks;
	}
 

	/**
	 * Restituisce lo stato di esecuzione dei controller
	 * @return true se uno dei controller ha generato un errore bloccante
	 */
	public boolean isInterrupted() {
		return interrupted;
	}
		
}
