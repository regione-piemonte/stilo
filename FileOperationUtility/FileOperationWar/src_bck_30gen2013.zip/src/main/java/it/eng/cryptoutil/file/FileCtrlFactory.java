package it.eng.cryptoutil.file;

public class FileCtrlFactory {

	public static CtrlBuilder getCtrlBuilder(){
		return new SpringCtrlBuilder();
	}
}
