package it.eng.cryptoutil.config;

import it.eng.utility.cryptosigner.utils.MessageConstants;

public interface CryptoWSMessage extends MessageConstants {
	//format recognition message
	String FR_MIME_UNKNOWN="FR.MIME_UNKNOWN";
	String FR_FORMAT_NOT_FOUND="FR.FORMAT_NOT_FOUND";
	String FR_DB_ERROR="FR.DB_ERROR";
}
