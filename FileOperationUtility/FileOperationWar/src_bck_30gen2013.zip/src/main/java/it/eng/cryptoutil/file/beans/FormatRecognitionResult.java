package it.eng.cryptoutil.file.beans;

import it.eng.suiteutility.module.mimedb.entity.TAnagFormatiDig;
/**
 * bean che contiene i dati di ritorno dell controllo di formato
 * @author Russo
 *
 */
public class FormatRecognitionResult {
	//mimetype in tabella
	private String mimeType;
	//mimeType rilevato sul file
	private String mimetypeDetected;
	//dati del formato riconosciuto così come in tabella
	private TAnagFormatiDig datiFormato;
	//nome del file rinominato in base all'estensione del formato riconosciuto
	private String filename;
	
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getMimetypeDetected() {
		return mimetypeDetected;
	}
	public void setMimetypeDetected(String mimetypeDetected) {
		this.mimetypeDetected = mimetypeDetected;
	}
	public TAnagFormatiDig getDatiFormato() {
		return datiFormato;
	}
	public void setDatiFormato(TAnagFormatiDig datiFormato) {
		this.datiFormato = datiFormato;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	
}
