package it.eng.cryptoutil.file;

import org.springframework.context.ApplicationContext;

import it.eng.cryptoutil.verify.beans.AbstractInputOperationType;
import it.eng.cryptoutil.verify.beans.InputDigestType;
import it.eng.cryptoutil.verify.beans.InputFormatRecognitionType;
import it.eng.utility.cryptosigner.context.CryptoSignerApplicationContextProvider;

/**
 * mapping fra i controller e i relativi input Type
 * ognni inputtype è mappato ad un controller configurato in spring
 * gli input type possono anche essere usati per customizzare proprietà del controller costruito
 * facendo ilmerge della conf di default con i parametri ricevuti
 *  
 */
public class SpringCtrlBuilder implements CtrlBuilder {
	 public    IFileController build(AbstractInputOperationType input){
		 IFileController ret=null;
		 ApplicationContext context=CryptoSignerApplicationContextProvider.getContext();
		 if(input instanceof InputFormatRecognitionType){
			 ret=context.getBean(FormatRecognitionCtrl.class);
		 }else  if(input instanceof InputDigestType){
			 ret=context.getBean(DigestCtrl.class);
		 }
		 return ret;
	 }
}
