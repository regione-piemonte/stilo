package it.eng.cryptoutil.verify.util;

import it.eng.cryptoutil.verify.beans.InputFile;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;

import javax.activation.DataHandler;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * costruisce un file in base alle varie possibilità date da InputFile
 *
 */

public class InputFileUtil {
	private static final Logger log = LogManager.getLogger(InputFile.class);
	
	public static File getTempFile(InputFile input)throws Exception{
		File file=null;
		if(input.getFileStream()!=null){
			//read File from DataHandler
			DataHandler dh=input.getFileStream();
			  file=File.createTempFile("input", "stemp");
			try {
				IOUtils.copyLarge(dh.getInputStream(), new FileOutputStream(file));
			} catch (Exception e) {
				 log.fatal("fatal creating file from stream",e);
				 //throw new CryptoServiceException("input non valido");
				//TODO manage
			}
			return file;
		}else if(input.getFileUrl()!=null){
			// produce from URL
			try{
			file=File.createTempFile("input", "stemp");
			FileUtils.copyURLToFile(new URL(input.getFileUrl()), file);
			}catch(Exception ex){
				ex.printStackTrace();
				//TODO manage
				
			}
		}else{
			//TODO other
		}
		return file;
	}
}
