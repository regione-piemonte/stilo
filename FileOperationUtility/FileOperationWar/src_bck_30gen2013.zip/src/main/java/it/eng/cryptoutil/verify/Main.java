package it.eng.cryptoutil.verify;

import it.eng.core.config.ConfigUtil;
import it.eng.cryptoutil.verify.beans.FileOperation;
import it.eng.utility.cryptosigner.FactorySigner;

import java.security.Security;

import javax.xml.ws.Endpoint;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//carico spring
		try {
			ConfigUtil.initialize();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Security.addProvider(new BouncyCastleProvider());
		//ApplicationContext context = new ClassPathXmlApplicationContext("ControllerConfig.xml");
//		 
//		System.out.println("starting..");
		 //Endpoint.publish("http://localhost:9999/ws/cert", new CertificateVerifierImpl());
		 Endpoint.publish("http://localhost:9999/ws/fileop", new  FOImpl());
		 System.out.println("started...");

	}

}
