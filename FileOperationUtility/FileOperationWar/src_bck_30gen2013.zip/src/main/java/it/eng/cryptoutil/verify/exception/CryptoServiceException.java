package it.eng.cryptoutil.verify.exception;

public class CryptoServiceException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9176919503556982412L;

}
