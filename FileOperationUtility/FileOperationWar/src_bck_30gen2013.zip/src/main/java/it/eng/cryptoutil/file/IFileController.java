package it.eng.cryptoutil.file;

import it.eng.cryptoutil.file.beans.OutputOperations;
import it.eng.cryptoutil.verify.beans.AbstractInputOperationType;
import it.eng.cryptoutil.verify.beans.InputFileOperationType;
import it.eng.utility.cryptosigner.controller.exception.ExceptionController;

import java.util.List;

public interface IFileController {
	public boolean execute(InputFileBean input,AbstractInputOperationType customInput, OutputOperations output)throws ExceptionController;
	public int getPriority();
	public List<IFileController> getPredecessors();
	public boolean isCritical() ;
}
