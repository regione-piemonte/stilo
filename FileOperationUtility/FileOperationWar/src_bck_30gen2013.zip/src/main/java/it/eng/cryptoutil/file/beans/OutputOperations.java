package it.eng.cryptoutil.file.beans;

import it.eng.cryptoutil.verify.beans.AbstractResponseOperationType;
import it.eng.cryptoutil.verify.beans.AbstractResponseOperationType.ErrorsMessage;
import it.eng.cryptoutil.verify.beans.AbstractResponseOperationType.Warnings;
import it.eng.cryptoutil.verify.beans.VerificationStatusType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * bean che conserva l'output di tutte le operazioni
 * @author Russo
 *
 */
public class OutputOperations {
	Map<String, AbstractResponseOperationType> controllerResult = new LinkedHashMap<String, AbstractResponseOperationType>();


	/**
	 * @return the controllerResult
	 */
	public Map<String, AbstractResponseOperationType> getControllerResult() {
		return controllerResult;
	}

	/**
	 * @param controllerResult the controllerResult to set
	 */
	public void setControllerResult(Map<String, AbstractResponseOperationType> controllerResult) {
		this.controllerResult = controllerResult;
	}
	
	public void addResult(String controllerName, AbstractResponseOperationType result){
		if (controllerResult==null){
			controllerResult = new HashMap<String, AbstractResponseOperationType>();
		}
		if(controllerResult.containsKey(controllerName)){
			AbstractResponseOperationType resultbean = controllerResult.get(controllerName);
//			resultbean.getExtractedProperties().putAll(result.getExtractedProperties());
//			if(result.getValidationInfos()!=null){
//				if(result.getValidationInfos().getErrors()!=null){
//					resultbean.addErrors(result.getValidationInfos().getErrors());
//				}
//				if(result.getValidationInfos().getWarnings()!=null){
//					resultbean.addWarnings(result.getValidationInfos().getWarnings());
//				}
//			}
		}else{
			controllerResult.put(controllerName, result);	
		}
	}
	
	public AbstractResponseOperationType getResult(String controllername){
		return controllerResult==null? null : controllerResult.get(controllername);
	}

	@Override
	public String toString() {
		return "OutputOperations [controllerResult=" + controllerResult + "]";
	}
	
	public List<AbstractResponseOperationType> getResponses(){
		List<AbstractResponseOperationType> ret = new ArrayList<AbstractResponseOperationType>();
		ret.addAll(getControllerResult().values());
		return ret;
	}
	
	public void addError(AbstractResponseOperationType result,String message){
		addError(result, message, null);
	}
	
	public void addError(AbstractResponseOperationType result,String message,VerificationStatusType status){
		
		if(result.getErrorsMessage()==null){
			ErrorsMessage em= new ErrorsMessage();
			result.setErrorsMessage(em);
		}
		result.getErrorsMessage().getErrMessage().add(message);
		
		if(status!=null){
			//imposto lo stato ad error sul risultato poichè l'errore non consente l'esecuzione
			//dell'operazione
			result.setVerificationStatus(status);
		}
	}
	
	public void addWarning(AbstractResponseOperationType result,String message){
		
		if(result.getErrorsMessage()==null){
			Warnings em= new Warnings();
			result.setWarnings(em);
		}
		result.getWarnings().getWarnMessage().add(message);
		
		 
	}
}
