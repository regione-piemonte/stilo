package it.eng.cryptoutil.file;

import it.eng.cryptoutil.file.beans.OutputOperations;
import it.eng.cryptoutil.verify.beans.AbstractInputOperationType;
import it.eng.utility.cryptosigner.controller.exception.ExceptionController;

public class DigestCtrl extends AbstractFileController {

	 

	@Override
	public boolean execute(InputFileBean input, AbstractInputOperationType customInput, OutputOperations output)
			throws ExceptionController {
		boolean ret=false;
		return ret;
	}

}
