package it.eng.cryptoutil;


import it.eng.core.config.ConfigUtil;
import it.eng.core.service.bean.IrisCall;
import it.eng.core.service.bean.MetadataRegistry;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Inizializzaione del contesto 
 * @author michele
 *
 */
public class ContextListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void contextInitialized(ServletContextEvent event) {
		
		//Inizializzo il business client
//		HibernateUtil.setEntitypackage("it.eng.iris.module.corebusiness.business.entity");
//		
//		org.hibernate.cfg.Configuration config = new org.hibernate.cfg.Configuration();
//		HibernateUtil.settingDefaultListener(config);
//		HibernateUtil.addSessionFactory("trasversale", config.configure());	
//		HibernateUtil.addEnte("ente", "trasversale");
//		// configuro la chiave per l'audit
	    try {
			ConfigUtil.initialize();
			//test Registry
			System.out.println("**********************************************");
			System.out.println(MetadataRegistry.getInstance().getModuleMap());
			System.out.println("**********************************************");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException("fatal initizalizion Business Runtime",e);
		}
		//
		//IrisCall.clearReflections();
		//IrisCall.getReflectionService();
		
		
		
	}

	
	
}
