package it.eng.cryptoutil.file;

import it.eng.cryptoutil.config.CryptoWSMessage;
import it.eng.cryptoutil.file.beans.OutputOperations;
import it.eng.cryptoutil.verify.beans.AbstractInputOperationType;
import it.eng.cryptoutil.verify.beans.InputFileOperationType;
import it.eng.cryptoutil.verify.beans.ResponseFormatRecognitionType;
import it.eng.cryptoutil.verify.beans.VerificationStatusType;
import it.eng.suiteutility.mimedetector.MimeDetectorException;
import it.eng.suiteutility.mimedetector.implementations.mimeutils.MimeUtilsAdapter;
import it.eng.suiteutility.module.mimedb.DaoAnagraficaFormatiDigitali;
import it.eng.suiteutility.module.mimedb.entity.TAnagFormatiDig;
import it.eng.utility.cryptosigner.controller.exception.ExceptionController;
import it.eng.utility.cryptosigner.utils.MessageHelper;

import javax.activation.MimeType;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
/**
 * riconoscimento del formato
 * @author Russo
 *
 */
public class FormatRecognitionCtrl extends AbstractFileController {
	//nome prop che contiene l'oggeto di output  dell'operazione (bean che contien formato etc.)
	public static final String FORMAT_RESULT="format result";
	//prop che contiene la validazione dell'operazione ed eventuali errori (validationinfo)
	public static final String FORMAT_VALIDATION_INFO="format validation info";

	public static final  Logger log=LogManager.getLogger(FormatRecognitionCtrl.class);
	
	
	
	@Override
	public boolean execute(InputFileBean input,AbstractInputOperationType customInput, OutputOperations output)
	throws ExceptionController {
		boolean ret=false;
		//risultato dell'operazione
		ResponseFormatRecognitionType  opResult = new ResponseFormatRecognitionType();
		 
		MimeUtilsAdapter adapter = new MimeUtilsAdapter();
		MimeType mimeType=null;
		try {
			mimeType = adapter.detectBest(input.getInputFile());
		} catch (MimeDetectorException e) {
			log.fatal("mime adataper error ",e);
			output.addError(opResult,MessageHelper.getMessage(CryptoWSMessage.FR_MIME_UNKNOWN),VerificationStatusType.KO);
		}
		String mimeTypeString=""+mimeType;
		DaoAnagraficaFormatiDigitali dao= new DaoAnagraficaFormatiDigitali();
		TAnagFormatiDig formato=null;
		try {
			 formato=dao.findFormatByMimeType(mimeTypeString);
		} catch (Exception e) {
			log.fatal("fatal finding format",e);
			output.addError(opResult,MessageHelper.getMessage(CryptoWSMessage.FR_DB_ERROR),VerificationStatusType.KO);
		}
		if(formato==null){
			ret=false;
			output.addError(opResult,MessageHelper.getMessage(CryptoWSMessage.FR_FORMAT_NOT_FOUND),VerificationStatusType.KO);
		}else{
			ret=true;
			//costruisco il bean risultato
			opResult.setVerificationStatus(VerificationStatusType.OK);
			//opResult.setDatiFormato(formato);
			//opResult.setMimetypeDetected(mimeTypeString);
			opResult.setMimeType(formato.getMimetypePrincipale());
			if(!StringUtils.isBlank(input.getFileName())){
				//TODO calcola il rinominato
			}
			 
			
		}
		output.addResult(this.getClass().getName(), opResult); 
		return ret;
	}





}
