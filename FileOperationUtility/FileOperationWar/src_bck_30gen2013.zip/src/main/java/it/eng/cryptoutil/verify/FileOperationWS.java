package it.eng.cryptoutil.verify;

import it.eng.cryptoutil.verify.beans.FileOperation;
import it.eng.cryptoutil.verify.beans.FileOperationResults;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.xml.ws.soap.MTOM;

@WebService
@MTOM(enabled=true)
@SOAPBinding(style = Style.DOCUMENT)
public interface FileOperationWS {
  
	public FileOperationResults check(FileOperation input);
}
