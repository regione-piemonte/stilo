package it.eng.cryptoutil.file;

import it.eng.cryptoutil.file.beans.OutputOperations;
import it.eng.cryptoutil.verify.beans.AbstractInputOperationType;
import it.eng.utility.cryptosigner.controller.exception.ExceptionController;

import java.util.ArrayList;
import java.util.List;

/**
 * controller di base per le operazioni sui file
 */
public abstract class AbstractFileController  implements IFileController {
	//controller bloccante se fallisce
	protected boolean critical = false;
	
	public boolean isCritical() {
		return critical;
	}

	public void setCritical(boolean critical) {
		this.critical = critical;
	}

	private List<IFileController> predecessors= new ArrayList<IFileController>();
	 

	public List<IFileController> getPredecessors() {
		return predecessors;
	}

	public void setPredecessors(List<IFileController> predecessors) {
		this.predecessors = predecessors;
	}

	private int priority;
	
//	public boolean execute(InputFileBean input,OutputFileBean output)throws ExceptionController{
//		  execute((InputFileBean)input, (OutputFileBean)output);
//		 
//	}
	
	public abstract boolean execute(InputFileBean input,AbstractInputOperationType customInput, OutputOperations output) throws ExceptionController;

	 

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	
}
