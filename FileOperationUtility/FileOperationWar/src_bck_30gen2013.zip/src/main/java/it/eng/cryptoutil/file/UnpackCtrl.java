package it.eng.cryptoutil.file;

import it.eng.cryptoutil.file.beans.OutputOperations;
import it.eng.cryptoutil.file.beans.ResultBean;
import it.eng.cryptoutil.verify.beans.AbstractInputOperationType;
import it.eng.cryptoutil.verify.beans.InputFileOperationType;
import it.eng.cryptoutil.verify.beans.ResponseUnpackType;
import it.eng.cryptoutil.verify.beans.VerificationStatusType;
import it.eng.utility.cryptosigner.controller.exception.ExceptionController;
import it.eng.utility.cryptosigner.data.AbstractSigner;
import it.eng.utility.cryptosigner.data.SignerUtil;
import it.eng.utility.cryptosigner.data.type.SignerType;
import it.eng.utility.cryptosigner.exception.CryptoSignerException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class UnpackCtrl extends AbstractFileController {
	public static final  Logger log=LogManager.getLogger(UnpackCtrl.class);
	//file estratto dalle buste (File)
	public static final String EXTRACTED_FILE = "extractedFile";
	// indica se il file è firmato (boolean)
	public static final String IS_ROOT_SIGNED = "isRootSigned";
	// chiave identificativa della operazione
	public static final String UnpackCtrlCode=UnpackCtrl.class.getName();
	
	//file temporaneo estratto dalla busta
	private static File extracttempfile;
	
	@Override
	public boolean execute(InputFileBean input, AbstractInputOperationType customInput, OutputOperations output)
			throws ExceptionController {
		ResponseUnpackType response= new ResponseUnpackType();
		boolean ret=false;
		try {
			//TODO add file to result
			File documentFile=input.getInputFile();
			File extractedFile = extractDocumentFile(documentFile);
			//rb.addProperty(EXTRACTED_FILE, extractedFile);
			if (extractedFile != documentFile)
				;//rb.addProperty(IS_ROOT_SIGNED, true);
			else
				;//rb.addProperty(IS_ROOT_SIGNED, false);
			ret=true;
		} catch (IOException e) {
			log.fatal("fatal estracting..",e);
			output.addError(response,e.getMessage(),VerificationStatusType.KO);
		}
		output.addResult(UnpackCtrlCode, response);
		return ret;
	}
	
	/**
	 * estrae ricorsivamente il file dalle buste innestate
	 * @param documentFile
	 * @return
	 * @throws IOException
	 */
	private File extractDocumentFile(File documentFile) throws IOException {
		
		AbstractSigner signer = null;
		try {
			signer = SignerUtil.newInstance().getSignerManager(documentFile);
		} catch (CryptoSignerException e) {
			// Se arriva qua non e' stato trovato alcun signer per cui o il file non è firmato o 
			//è firmato in maniera ignota al cryptosigner
		}
		if (signer!=null) {
			InputStream stream = signer.getContentAsInputStream();
			if (stream!=null) {
				if (extracttempfile!=null) {
					//cancello i lprcedente
					extracttempfile.delete();
				}
				extracttempfile = File.createTempFile("Extract", "file");
				IOUtils.copyLarge(stream, new FileOutputStream(extracttempfile));
				if(signer.getFormat().equals(SignerType.PAdES)){
					return extracttempfile;
				}
				return extractDocumentFile(extracttempfile);
			} else {
				return documentFile;
			}
		} else {
			return documentFile;
		}
	}
}
