package it.test.client;

import it.eng.cryptoutil.verify.CertificateVerifier;
import it.eng.cryptoutil.verify.beans.VerificationInfo;
import it.eng.cryptoutil.verify.beans.VerificationRequest;
import it.eng.cryptoutil.verify.beans.VerificationTypes;

import java.io.ByteArrayInputStream;
import java.net.URL;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.Enumeration;

import javax.security.auth.Subject;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import sun.security.pkcs11.SunPKCS11;

public class WsClient {
	
	public static void main(String[] args) {
		try{
		URL url = new URL("http://localhost:9900/ws/cert?wsdl");
		QName qname = new QName("http://verify.cryptoutil.eng.it/", "CertificateVerifierImplService");

		Service service = Service.create(url, qname);
		CertificateVerifier verifier = service.getPort(CertificateVerifier.class);
		StringBuffer cardConfig=new StringBuffer();
		cardConfig.append ("name=SmartCards \n");
		cardConfig.append ("slot="+0+" \n");
		cardConfig.append ("library="+"C:\\SoftHSM\\lib\\libsofthsm.dll");

		ByteArrayInputStream confStream = new ByteArrayInputStream(cardConfig.toString().getBytes());
		SunPKCS11 provider = new sun.security.pkcs11.SunPKCS11(confStream);
		provider.login(new Subject(), new PasswordHandler("12345".toCharArray()));
		Security.addProvider(provider);
		KeyStore keyStore = KeyStore.getInstance("PKCS11",provider);
	 	keyStore.load(null,null);		 	
	 	 Enumeration enumeration = keyStore.aliases();
	        
	        while(enumeration.hasMoreElements()){
	        	
	        	String alias = enumeration.nextElement().toString();
	        	System.out.println("alias:"+alias);
	        	 
	            X509Certificate certificate=(X509Certificate)keyStore.getCertificate(alias);
	            VerificationRequest input = new VerificationRequest();
	            input.setX509Cert(certificate.getEncoded());
	            
	            VerificationInfo vinfo= new VerificationInfo();
	            vinfo.setName("test");vinfo.setVerificationID(VerificationTypes.CERTIFICATE_EXPIRATION);
	            
	            input.getVerificationInfo().add(vinfo);
	            
	            verifier.check(input);
	        }
		}catch(Exception ex){
			ex.printStackTrace();
		}

	}
	
}//end class
