package it.eng.cryptoutil.verify;

import it.eng.cryptoutil.verify.beans.VerificationRequest;
import it.eng.cryptoutil.verify.beans.VerificationResults;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style = Style.DOCUMENT)
public interface CertificateVerifier {
	
	public VerificationResults check(VerificationRequest input);
}
