package it.eng.cryptoutil.verify;

import it.eng.utility.cryptosigner.FactorySigner;

import java.security.Security;

import javax.xml.ws.Endpoint;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//carico spring
		Security.addProvider(new BouncyCastleProvider());
		ApplicationContext context = new ClassPathXmlApplicationContext("ControllerConfig.xml");
//		 
//		System.out.println("starting..");
		 Endpoint.publish("http://localhost:9999/ws/cert", new CertificateVerifierImpl());
		 System.out.println("started...");

	}

}
