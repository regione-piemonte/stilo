package it.eng.cryptoutil.config;

import it.eng.core.annotation.Module;
import it.eng.core.config.IModuleConfigurator;

import org.apache.log4j.Logger;

@Module(name=CriptoUtilityConfig.modulename ,version="0.0.1-SNAPSHOT")
public class CriptoUtilityConfig implements IModuleConfigurator {
	public static final String modulename="CriptoUtilityConfig";
	
	private static final Logger log = Logger.getLogger(CriptoUtilityConfig.class);
	
	@Override
	public void init() throws Exception {
		 
		log.info("initialization...");
		 
	}

	@Override
	public void destroy() throws Exception {
		// logica in caso di destroy del servizio
	}

}
